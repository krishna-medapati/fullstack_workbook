# Skill 3 - HQL Operations
