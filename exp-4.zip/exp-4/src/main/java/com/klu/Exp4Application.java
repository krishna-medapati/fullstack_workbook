package com.klu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp4Application {
    public static void main(String[] args) {
        SpringApplication.run(Exp4Application.class, args);
    }
}